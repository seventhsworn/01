from PIL import Image, ImageColor

shrimp = Image.open(r'C:\Users\ashly\OneDrive\Desktop\SOFT t\Week_4_Lab_Activities\Week_4_Lab_Activities\Assets\SHRIMP.png') 
bug = Image.open(r'C:\Users\ashly\OneDrive\Desktop\SOFT t\Week_4_Lab_Activities\Week_4_Lab_Activities\Assets\GREEN BUG.png') 
worm = Image.open(r'C:\Users\ashly\OneDrive\Desktop\SOFT t\Week_4_Lab_Activities\Week_4_Lab_Activities\Assets\WORM.png') 


#for shrimp
print(shrimp.getpixel((0,0)))

shrimp_red = shrimp.getchannel('R')
shrimp_blue = shrimp.getchannel('B')
shrimp_red.show()
shrimp_blue.show()


#for bug
print(bug.getpixel((0,0)))

bug_red = bug.getchannel('R')
bug_blue = bug.getchannel('B')
bug_red.show()
bug_blue.show()


#for worm
print(worm.getpixel((0,0)))

worm_red = worm.getchannel('R')
worm_blue = worm.getchannel('B')
worm_red.show()
worm_blue.show()

#shows both greyscale / contrast for all three bugs (insects or whatever man)