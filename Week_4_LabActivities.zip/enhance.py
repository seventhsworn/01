from PIL import Image, ImageEnhance 

shrimp = Image.open(r'C:\Users\ashly\OneDrive\Desktop\SOFT t\Week_4_Lab_Activities\Week_4_Lab_Activities\Assets\SHRIMP.png') 
bug = Image.open(r'C:\Users\ashly\OneDrive\Desktop\SOFT t\Week_4_Lab_Activities\Week_4_Lab_Activities\Assets\GREEN BUG.png') 
worm = Image.open(r'C:\Users\ashly\OneDrive\Desktop\SOFT t\Week_4_Lab_Activities\Week_4_Lab_Activities\Assets\WORM.png') 

shrimp_enhanced = ImageEnhance.Color(shrimp).enhance(2)
shrimp_enhanced = ImageEnhance.Contrast(shrimp_enhanced).enhance(45)
shrimp_enhanced = ImageEnhance.Brightness(shrimp_enhanced).enhance(3)
shrimp_enhanced = ImageEnhance.Sharpness(shrimp_enhanced).enhance(5)
print("shrimp works")

bug_enhanced = ImageEnhance.Color(bug).enhance(100)
bug_enhanced = ImageEnhance.Contrast(bug_enhanced).enhance(45)
bug_enhanced = ImageEnhance.Brightness(bug_enhanced).enhance(67)
bug_enhanced = ImageEnhance.Sharpness(bug_enhanced).enhance(5)
print("bug works")

worm_enhanced = ImageEnhance.Color(worm).enhance(99)
worm_enhanced = ImageEnhance.Contrast(worm_enhanced).enhance(67)
worm_enhanced = ImageEnhance.Brightness(worm_enhanced).enhance(67)
worm_enhanced = ImageEnhance.Sharpness(worm_enhanced).enhance(67)
print("worm works")


shrimp.show()
shrimp_enhanced.show()

bug.show()
bug_enhanced.show()

worm.show()
worm_enhanced.show()