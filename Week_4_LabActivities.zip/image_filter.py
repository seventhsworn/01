from PIL import Image, ImageFilter 
# new variablez for the insects
shrimp = Image.open(r'C:\Users\ashly\OneDrive\Desktop\SOFT t\Week_4_Lab_Activities\Week_4_Lab_Activities\Assets\SHRIMP.png') 
bug = Image.open(r'C:\Users\ashly\OneDrive\Desktop\SOFT t\Week_4_Lab_Activities\Week_4_Lab_Activities\Assets\GREEN BUG.png') 
worm = Image.open(r'C:\Users\ashly\OneDrive\Desktop\SOFT t\Week_4_Lab_Activities\Week_4_Lab_Activities\Assets\WORM.png') 

shrimp_blur = shrimp.filter(ImageFilter.BLUR) 
shrimp_contour = shrimp.filter(ImageFilter.CONTOUR) 
shrimp_edge = shrimp.filter(ImageFilter.FIND_EDGES)  


bug_emboss = bug.filter(ImageFilter.EMBOSS) 
bug_boxblur = bug.filter(ImageFilter.BoxBlur(radius = 50)) 
print("bug works")

worm_gaussianblur = worm.filter(ImageFilter.GaussianBlur(radius = 6)) 
worm_unsharp = worm.filter(ImageFilter.UnsharpMask(radius = 100)) 

#show everything 
bug_boxblur.show() 
worm_gaussianblur.show()
shrimp_edge.show()
