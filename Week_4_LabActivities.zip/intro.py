from PIL import Image
print("pillow installed")

#this is variable, like local function for all the bugs 
shrimp = Image.open(r'C:\Users\ashly\OneDrive\Desktop\SOFT t\Week_4_Lab_Activities\Week_4_Lab_Activities\Assets\SHRIMP.png') 
bug = Image.open(r'C:\Users\ashly\OneDrive\Desktop\SOFT t\Week_4_Lab_Activities\Week_4_Lab_Activities\Assets\GREEN BUG.png') 
worm = Image.open(r'C:\Users\ashly\OneDrive\Desktop\SOFT t\Week_4_Lab_Activities\Week_4_Lab_Activities\Assets\WORM.png') 
print("works")

print(shrimp.size)
print(shrimp.filename)
print(shrimp.format)


#rotate
shrimp = shrimp.transpose(Image.Transpose.ROTATE_90)
shrimp.show()

bug_rotated = bug.rotate(25)
bug_rotated.save('img_rotated.png', 'png')
print("bug works")
bug_rotated.show()