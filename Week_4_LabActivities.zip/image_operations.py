from PIL import Image, ImageOps 
shrimp = Image.open(r'C:\Users\ashly\OneDrive\Desktop\SOFT t\Week_4_Lab_Activities\Week_4_Lab_Activities\Assets\SHRIMP.png') 
bug = Image.open(r'C:\Users\ashly\OneDrive\Desktop\SOFT t\Week_4_Lab_Activities\Week_4_Lab_Activities\Assets\GREEN BUG.png') 
worm = Image.open(r'C:\Users\ashly\OneDrive\Desktop\SOFT t\Week_4_Lab_Activities\Week_4_Lab_Activities\Assets\WORM.png') 

shrimp_mirror = ImageOps.mirror(shrimp) 
bug_scale = ImageOps.scale(bug, 0.5) 
shrimp_inverted = ImageOps.invert(shrimp_mirror) 

shrimp_border = ImageOps.expand( 
    image = shrimp_inverted,  
    border = 50, 
    fill = (255,255,255)) 
print("shrimp works")


worm_padded = ImageOps.pad(worm, (4000,6000)) 
worm_crop = ImageOps.crop(image = worm, border = 200)

shrimp_border.show() 
worm_crop.show()
bug_scale.show() 