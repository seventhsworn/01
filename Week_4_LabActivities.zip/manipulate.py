from PIL import Image

shrimp = Image.open(r'C:\Users\ashly\OneDrive\Desktop\SOFT t\Week_4_Lab_Activities\Week_4_Lab_Activities\Assets\SHRIMP.png') 
bug = Image.open(r'C:\Users\ashly\OneDrive\Desktop\SOFT t\Week_4_Lab_Activities\Week_4_Lab_Activities\Assets\GREEN BUG.png') 
worm = Image.open(r'C:\Users\ashly\OneDrive\Desktop\SOFT t\Week_4_Lab_Activities\Week_4_Lab_Activities\Assets\WORM.png') 

shrimp_transpose = shrimp.transpose(Image.Transpose.ROTATE_180)

bug_rotate = bug.rotate(45, expand = False, center = (0,0)) 

worm_crop = worm.crop((800,600,1600,1600)) 

worm_resize = worm.resize((2000,600)) 

#all bugs shown here 
worm_resize.show()
bug_rotate.show()
shrimp_transpose.show() 